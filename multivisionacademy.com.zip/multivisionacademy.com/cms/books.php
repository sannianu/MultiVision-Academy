<?php  include "includes/db.php"; ?>
 <?php  include "includes/header.php"; ?>


    <!-- Navigation -->
     <?php  include "includes/navigation.php"; ?>    
    <!-- -->
    
    <!-- LOGO -->
    <div class="container text-center">
        <p>
            <img src="./images/logo.png">
            <h1> <i class="fas fa-book"></i> E-Library</h1>
        </p>
    </div>
    
    <!-- Page Content -->
    <div class="container">
        <div>
            <!-- Book 1 -->
            <h1>ISLAMIC BOOKS</h1>
            <h3>Meadow of the Beginners - رَوْضَة البَادِئِين مِنْ أَحَادِيْثِ سَيِّدِ المُرْسَلِين</h3>
            <h3>From the Narrations of the Leader of the Messengers</h3>
            <h4>Authored by<br>
                            Abū ʿAbdillāh Muḥammad bin ʿAlī bin Ḥizām al-Faḍlī al-Baʿdānī</h4>
            <object data="./pdf/meadow_-of_-the_beginners.pdf" type="application/pdf" width="100%" height="768px"></object> <br>
            <!-- <a href="multivisionacademy.com.ng/cms/pdf/meadow_-of_-the_beginners.pdf">Download</a> -->
            <a href="https://localhost/cms/pdf/meadow_-of_-the_beginners.pdf">Download</a>

        </div>

        <div>
            <!-- Book 2 -->
            <h1>ISLAMIC BOOKS</h1>
        <h3>Hisnul Muslim - Citadel of the Believers</h3>
        <h3>From the Narrations of the Leader of the Messengers</h3>
        <h4>Authored by<br>
                       </h4>
        <object data="./pdf/fortress_of_the_muslim.pdf" type="application/pdf" width="100%" height="768px"></object> <br>
        <a href="multivisionacademy.com.ng/cms/pdf/fortress_of_the_muslim.pdf">Download</a>
        </div>

            <!-- ALTERNATIVE -->
       <!--  <iframe src="./pdf/ahkam.pdf" width="100%" height="768px">></iframe>

        <embed src="./pdf/ahkam.pdf" type="application/pdf" width="100%" height="768px">></embed>
        -->
    </div>
            
              

            <!-- Blog Sidebar Widgets Column -->
        <?php  include "includes/sidebar.php"; ?>            
           

            <!-- Embedded Scientific Calculator from math.tools -->
        <section>
            <div class="embedblock">
                <script src="https://math.tools/extensions/embed/v1/sc.js?v1"></script>
                <script>
                    MathToolsScCalc.Embed.render({context: 'calculator', toolId: 'scientific-calculator'});
                </script>
                <noscript>Please enable JavaScript to view the <a href="https://math.tools/scientific-calculator"> scientific calculator powered by math tools.</a> </noscript>
                <div class="light-text" style="text-decoration: none; color: #ccc; z-index: 999; text-align: left;padding-left: 20px; margin-top: -20px;" > <a href="https://math.tools/scientific-calculator" title="Powered by scientific calculator math.tools" style="text-decoration: none; color: #ccc;"> math.tools</a> </div>
            </div>
        </section>
             
      
        </div>
        <!-- /.row -->

        <hr>


        <ul class="pager">

        
   

<?php include "includes/footer.php";?>
