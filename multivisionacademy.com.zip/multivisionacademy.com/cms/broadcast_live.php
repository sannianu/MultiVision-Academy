<?php  include "includes/db.php"; ?>
 <?php  include "includes/header.php"; ?>


    <!-- Navigation -->
    
    <?php  include "includes/navigation.php"; ?>
    
    <!-- LOGO -->
    <div class="container text-center">
        <p>
            <img src="./images/logo.png">
            <h1> <i class="fas fa-book"></i> E-Learning</h1>
            <h3><i class="fas fa-youtube">Streaming Live</h3>
        </p>
    </div>
    
    <!-- Page Content -->

<br>

        <div class="container text-center">
            
                <!-- <iframe width="560" height="315" src="https://www.youtube.com/embed/live_stream?channel=UC4R8DWoMoI7CAwX8_LjQHig" frameborder="0" allowfullscreen></iframe> -->

                <iframe width="560" height="315" src="https://www.youtube.com/embed/-4yuG2KXvn4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
        
<?php include "includes/footer.php";?>
