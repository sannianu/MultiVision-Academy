<?php ob_start();

$db['db_host'] = "localhost:3306";
$db['db_user'] = "multivis_admin";
$db['db_pass'] = "lu@33#b69oWH";
$db['db_name'] = "multivis_users";

foreach($db as $key => $value){
define(strtoupper($key), $value);
}

$connection = mysqli_connect(DB_HOST, DB_USER,DB_PASS,DB_NAME);



$query = "SET NAMES utf8";
mysqli_query($connection,$query);

//if($connection) {
//
//echo "We are connected";
//
//}








?>