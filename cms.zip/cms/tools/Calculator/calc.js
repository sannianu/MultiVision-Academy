
function ud(n){
    let disp = document.getElementById("disp");
    disp.innerHTML += n ;

}
function ans(){
    c=eval(disp.innerHTML);
    disp.innerHTML=c;
}
function clc(){
    disp.innerHTML='';
}


  
